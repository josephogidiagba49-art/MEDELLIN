
REDDIT RSS → TELEGRAM ALERT BOT (Railway Ready)

FILES MUST BE AT ROOT LEVEL (NO FOLDER)

Start Command:
python bot.py

Environment Variables Required:
- TELEGRAM_TOKEN
- TELEGRAM_CHAT_ID
- SUBREDDITS
- KEYWORDS
- CHECK_INTERVAL (optional)

Uses Reddit RSS (no API keys).
